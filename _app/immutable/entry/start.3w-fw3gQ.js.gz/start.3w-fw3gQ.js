import{a as t}from"../chunks/entry.BGBXO2Zo.js";export{t as start};
