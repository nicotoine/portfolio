import{a as t}from"../chunks/entry.BXKzU5fa.js";export{t as start};
